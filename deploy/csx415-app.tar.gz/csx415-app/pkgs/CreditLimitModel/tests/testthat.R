library(testthat)
library(CreditLimitModel)

test_check("CreditLimitModel")
